#include "Collision.h"

Collision::Collision(Collider *A, Collider *B) {
	Collision::A = A;
	Collision::B = B;
}