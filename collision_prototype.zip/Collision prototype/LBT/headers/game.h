#ifndef __GAME_H__
#define __GAME_H__

#include <SDL.h>

#include "state.h"
#include "Timer.h"


typedef struct tile tile;
struct tile {
	SDL_Rect rect;
	bool is_water;
	bool is_wall;
};


class game_state : public state 
{
public:

	//initialization functions
	game_state(SDL_Renderer *renderer);
	~game_state();

	//inherited state functions
	bool enter();
	bool leave();
	bool draw();
	bool handle_event(const SDL_Event &event);

	//initialize variables
	const int TILE_SIZE = 40;

	tile map[32][18];

	int mouse_x,mouse_y;

	bool go_up;
	bool go_down;
	bool go_left;
	bool go_right;


	//////////////////////////////////////////////////////
	SDL_Rect sdlRect;

	int drawDoor();

	//structure for the door
	struct doorStruc
	{
    	int left;
    	int top;
    	int right;
    	int bottom;
	};

	// Define the coordinates of each side
	doorStruc door {100, 100, 300, 200};


	//making variables equivalent to the coordinates of each side
	SDL_Rect createSDLRect(const doorStruc& door) 
	{
		//SDL_Rect sdlRect;
    	sdlRect.x = door.left;
    	sdlRect.y = door.top;
    	sdlRect.w = door.right - door.left;
    	sdlRect.h = door.bottom - door.top;

    	return sdlRect;
   		 //return {rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top};
	}

	//check if the key is acquired
	bool keyNotGotten = true;

	//check if player touchd door
	bool checkCollision(/*const SDL_Rect& player , const SDL_Rect& door */) 
	{
    	return player.x < sdlRect.x + sdlRect.w &&
          	 player.x + player.w > sdlRect.x &&
          	 player.y < sdlRect.y + sdlRect.h &&
           	player.y + player.h > sdlRect.y;
	}	

	//////////////////////////////////////////////////


	SDL_Rect player;
	int player_vel;

	bool cycle;
};

extern Timer movement_timer, survival_timer;
extern bool quit;

#endif  /* __GAME_H__ */
