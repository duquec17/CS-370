C++ team project centered around constructing a game while also making use of SDL2 and not relying on structure of game engines. 
